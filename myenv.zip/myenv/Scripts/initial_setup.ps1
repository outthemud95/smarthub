# Create the necessary directories and files
New-Item -Path . -Name "app" -ItemType "directory"
New-Item -Path .\app -Name "__init__.py" -ItemType "file"
New-Item -Path .\app -Name "routes.py" -ItemType "file"
New-Item -Path . -Name "config.py" -ItemType "file"
New-Item -Path . -Name "run.py" -ItemType "file"

# Populate the files with basic content
Add-Content -Path .\app\__init__.py -Value @"
from flask import Flask

app = Flask(__name__)
app.config.from_object('config')

from app import routes
"@

Add-Content -Path .\app\routes.py -Value @"
from app import app

@app.route('/')
def index():
    return "Welcome to Smart Content Hub!"
"@

Add-Content -Path .\run.py -Value @"
from app import app

if __name__ == '__main__':
    app.run(debug=True)
"@

# Open the project in VS Code
code .