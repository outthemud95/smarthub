# script3_setup_blueprints.py
import os

BLUEPRINT_CONTENT = """
from flask import Blueprint

bp = Blueprint('bp_name', __name__)

@bp.route('/')
def index():
    return "Hello from bp_name!"
"""

blueprints_dir = os.path.join("C:\\smarthub\\myenv", "app", "blueprints")

# For demonstration, let's set up a single blueprint. You can expand this as needed.
bp_name = "sample"
bp_path = os.path.join(blueprints_dir, f"{bp_name}.py")

with open(bp_path, 'w') as bp_file:
    bp_file.write(BLUEPRINT_CONTENT.replace('bp_name', bp_name))

print(f"Blueprint {bp_name} created at {bp_path}")