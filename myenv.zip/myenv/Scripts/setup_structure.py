# setup_structure.py

import os

BASE_DIR = "C:\\smarthub\\myenv"

def create_structure():
    # List of directories to check/create
    directories = [
        'app',
        os.path.join('app', 'templates', 'auth'),
        os.path.join('app', 'static', 'css'),
        os.path.join('app', 'static', 'js'),
        os.path.join('app', 'static', 'images'),
        os.path.join('app', 'blueprints', 'auth'),
        os.path.join('app', 'models'),
        os.path.join('app', 'utils'),
        'Include',
        'Lib',
        'Scripts'
    ]
    
    for directory in directories:
        path = os.path.join(BASE_DIR, directory)
        if not os.path.exists(path):
            os.makedirs(path)
            print(f"Created directory: {path}")
        else:
            print(f"Directory already exists: {path}")

if __name__ == "__main__":
    create_structure()
