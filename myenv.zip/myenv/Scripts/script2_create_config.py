import os  # <-- Make sure this line is present

CONFIG_CONTENT = """
SECRET_KEY = 'your_secret_key_here'
SQLALCHEMY_DATABASE_URI = 'your_database_uri_here'
"""

config_path = os.path.join("C:\\smarthub\\myenv", "config.py")

with open(config_path, 'w') as config_file:
    config_file.write(CONFIG_CONTENT)

print(f"Configuration file created at {config_path}")