# script4_app_factory.py
import os

APP_FACTORY_CONTENT = """
from flask import Flask

def create_app():
    app = Flask(__name__)
    app.config.from_pyfile('config.py')

    # Register blueprints
    from .blueprints.sample import bp as sample_bp
    app.register_blueprint(sample_bp)

    return app
"""

app_factory_path = os.path.join("C:\\smarthub\\myenv", "app", "__init__.py")

with open(app_factory_path, 'w') as app_factory_file:
    app_factory_file.write(APP_FACTORY_CONTENT)

print(f"Application factory set up at {app_factory_path}")
