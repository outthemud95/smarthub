# script1_directory_setup.py

import os

# Define the base directory
BASE_DIR = "C:\\smarthub\\myenv"

# Define the directories to be created
directories = [
    os.path.join(BASE_DIR, "app", "blueprints"),
    os.path.join(BASE_DIR, "app", "static"),
    os.path.join(BASE_DIR, "app", "templates"),
    os.path.join(BASE_DIR, "app", "models"),
    os.path.join(BASE_DIR, "app", "forms"),
]

# Create directories
for directory in directories:
    if not os.path.exists(directory):
        os.makedirs(directory)
        print(f"Created: {directory}")
    else:
        print(f"Exists: {directory}")

print("Directory setup completed!")