# script5_run_script.py
import os

RUN_SCRIPT_CONTENT = """
from app import create_app

app = create_app()

if __name__ == '__main__':
    app.run(debug=True)
"""

run_script_path = os.path.join("C:\\smarthub\\myenv", "run.py")

with open(run_script_path, 'w') as run_script_file:
    run_script_file.write(RUN_SCRIPT_CONTENT)

print(f"Run script created at {run_script_path}")