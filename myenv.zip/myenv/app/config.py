
SECRET_KEY = 'your_secret_key_here'
SQLALCHEMY_DATABASE_URI = 'your_database_uri_here'
