
from flask import Blueprint

bp = Blueprint('sample', __name__)

@bp.route('/')
def index():
    return "Hello from sample!"
